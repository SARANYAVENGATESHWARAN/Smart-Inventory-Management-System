import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.linear_model import LinearRegression
from datetime import date, timedelta

st.set_page_config(page_title="Smart Inventory System", page_icon="📦", layout="wide")
st.title("📦 Smart Inventory Management System")
st.caption("Expiry Monitoring | Defect Analysis | Demand Prediction")

def create_sample_inventory():
    return pd.DataFrame({
        "item": ["Rice", "Wheat Flour", "Milk", "Cooking Oil", "Biscuits", "Sugar"],
        "category": ["Grains", "Grains", "Dairy", "Oil", "Snacks", "Grocery"],
        "quantity": [100, 60, 25, 40, 15, 80],
        "unit_price": [55, 42, 30, 120, 20, 45],
        "expiry_date": [
            date.today() + timedelta(days=120),
            date.today() + timedelta(days=60),
            date.today() + timedelta(days=5),
            date.today() + timedelta(days=180),
            date.today() - timedelta(days=2),
            date.today() + timedelta(days=90)
        ],
        "defect_count": [2, 0, 1, 0, 3, 0]
    })

def create_sample_sales():
    rows = []
    base_demand = {"Rice": 12, "Wheat Flour": 8, "Milk": 10,
                   "Cooking Oil": 4, "Biscuits": 6, "Sugar": 7}
    for product, baseline in base_demand.items():
        for day in range(30):
            rows.append({
                "date": date.today() - timedelta(days=29-day),
                "item": product,
                "demand": max(1, baseline + ((day % 5) - 2))
            })
    return pd.DataFrame(rows)

if "inventory" not in st.session_state:
    st.session_state.inventory = create_sample_inventory()
if "sales" not in st.session_state:
    st.session_state.sales = create_sample_sales()

st.sidebar.header("Project Navigation")
page = st.sidebar.radio("Select Module", [
    "Dashboard", "Inventory Management", "Expiry Monitoring",
    "Defect Analysis", "Demand Prediction", "Data Upload & Download"
])
st.sidebar.info("The application starts with sample demonstration data. Upload CSV files to analyse your own records.")

inventory = st.session_state.inventory.copy()
inventory["expiry_date"] = pd.to_datetime(inventory["expiry_date"]).dt.date
today = date.today()

if page == "Dashboard":
    st.header("Inventory Dashboard")
    expired_count = (inventory["expiry_date"] < today).sum()
    near_count = ((inventory["expiry_date"] >= today) &
                  (inventory["expiry_date"] <= today + timedelta(days=30))).sum()
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Products", len(inventory))
    c2.metric("Total Stock", int(inventory["quantity"].sum()))
    c3.metric("Expired Products", int(expired_count))
    c4.metric("Near Expiry", int(near_count))
    c5.metric("Defective Units", int(inventory["defect_count"].sum()))
    st.plotly_chart(px.bar(inventory, x="item", y="quantity", color="category",
                           title="Available Inventory Quantity"), width="stretch")
    inventory["status"] = inventory["expiry_date"].apply(
        lambda x: "Expired" if x < today else
        ("Near Expiry" if x <= today + timedelta(days=30) else "Safe"))
    counts = inventory["status"].value_counts().rename_axis("Status").reset_index(name="Count")
    st.plotly_chart(px.pie(counts, names="Status", values="Count",
                           title="Inventory Expiry Distribution"), width="stretch")
    st.dataframe(inventory, width="stretch")

elif page == "Inventory Management":
    st.header("Inventory Management")
    edited = st.data_editor(st.session_state.inventory, num_rows="dynamic",
                            width="stretch", key="inventory_editor")
    if st.button("Save Inventory Changes"):
        try:
            for col in ["quantity", "unit_price", "defect_count"]:
                edited[col] = pd.to_numeric(edited[col], errors="raise")
                if (edited[col] < 0).any():
                    raise ValueError(f"{col} cannot contain negative values.")
            edited["expiry_date"] = pd.to_datetime(edited["expiry_date"], errors="raise").dt.date
            st.session_state.inventory = edited
            st.success("Inventory updated successfully.")
        except Exception as exc:
            st.error(f"Please check the entered data: {exc}")
    st.subheader("Add a New Product")
    with st.form("add_product_form"):
        name = st.text_input("Product Name")
        category = st.text_input("Category")
        quantity = st.number_input("Quantity", min_value=0, step=1)
        price = st.number_input("Unit Price", min_value=0.0)
        expiry = st.date_input("Expiry Date", value=today)
        defects = st.number_input("Defect Count", min_value=0, step=1)
        submitted = st.form_submit_button("Add Product")
        if submitted:
            if not name.strip() or not category.strip():
                st.error("Enter both product name and category.")
            elif name.strip().lower() in st.session_state.inventory["item"].astype(str).str.lower().values:
                st.error("This product already exists. Edit its existing row.")
            else:
                new_row = pd.DataFrame([{
                    "item": name.strip(), "category": category.strip(),
                    "quantity": quantity, "unit_price": price,
                    "expiry_date": expiry, "defect_count": defects
                }])
                st.session_state.inventory = pd.concat(
                    [st.session_state.inventory, new_row], ignore_index=True)
                st.success("New product added.")
                st.rerun()

elif page == "Expiry Monitoring":
    st.header("Expiry Monitoring")
    inventory["days_to_expiry"] = inventory["expiry_date"].apply(lambda x: (x-today).days)
    expired = inventory[inventory["days_to_expiry"] < 0]
    near = inventory[(inventory["days_to_expiry"] >= 0) & (inventory["days_to_expiry"] <= 30)]
    safe = inventory[inventory["days_to_expiry"] > 30]
    st.metric("Expired Products", len(expired))
    st.subheader("Expired Stock")
    st.dataframe(expired, width="stretch")
    st.subheader("Products Expiring Within 30 Days")
    st.dataframe(near, width="stretch")
    st.subheader("Safe Stock")
    st.dataframe(safe, width="stretch")

elif page == "Defect Analysis":
    st.header("Defect Analysis")
    st.metric("Total Defective Units", int(inventory["defect_count"].sum()))
    defective = inventory[inventory["defect_count"] > 0].copy()
    if not defective.empty:
        st.dataframe(defective, width="stretch")
        st.plotly_chart(px.bar(defective, x="item", y="defect_count", color="category",
                               title="Defective Units by Product"), width="stretch")
    else:
        st.success("No defective products found.")
    inventory["defect_percentage"] = np.where(
        inventory["quantity"] > 0,
        inventory["defect_count"] / inventory["quantity"] * 100, 0)
    st.subheader("Defect Percentage")
    st.dataframe(inventory[["item", "quantity", "defect_count", "defect_percentage"]],
                 width="stretch")

elif page == "Demand Prediction":
    st.header("7-Day Product Demand Prediction")
    sales = st.session_state.sales.copy()
    sales["date"] = pd.to_datetime(sales["date"])
    product = st.selectbox("Select Product", sorted(sales["item"].unique()))
    history = sales[sales["item"] == product].sort_values("date").copy()
    if len(history) >= 2:
        history["day_number"] = np.arange(len(history))
        model = LinearRegression().fit(history[["day_number"]], history["demand"])
        future_x = np.arange(len(history), len(history)+7).reshape(-1, 1)
        predicted = np.maximum(0, model.predict(
            pd.DataFrame(future_x, columns=["day_number"])))
        forecast = pd.DataFrame({
            "Date": [today + timedelta(days=i) for i in range(1, 8)],
            "Predicted Demand": np.round(predicted, 2)
        })
        st.metric("Estimated 7-Day Demand", f"{predicted.sum():.0f} units")
        st.dataframe(forecast, width="stretch")
        past = history[["date", "demand"]].rename(columns={"date": "Date", "demand": "Demand"})
        past["Type"] = "Historical"
        future = forecast.rename(columns={"Predicted Demand": "Demand"})
        future["Type"] = "Predicted"
        chart_data = pd.concat([past, future], ignore_index=True)
        st.plotly_chart(px.line(chart_data, x="Date", y="Demand", color="Type",
                                markers=True, title=f"Demand Forecast: {product}"),
                        width="stretch")
        st.caption("Linear Regression estimate based on the available sales history; it is not a guarantee.")
    else:
        st.warning("At least two sales records are required.")

elif page == "Data Upload & Download":
    st.header("Data Upload & Download")
    st.subheader("Upload Inventory CSV")
    st.write("Required columns: item, category, quantity, unit_price, expiry_date, defect_count")
    inv_file = st.file_uploader("Choose Inventory CSV", type=["csv"], key="inv_upload")
    if inv_file is not None:
        try:
            uploaded = pd.read_csv(inv_file)
            required = {"item", "category", "quantity", "unit_price", "expiry_date", "defect_count"}
            if not required.issubset(uploaded.columns):
                st.error("Missing columns: " + ", ".join(sorted(required - set(uploaded.columns))))
            else:
                for col in ["quantity", "unit_price", "defect_count"]:
                    uploaded[col] = pd.to_numeric(uploaded[col], errors="raise")
                    if (uploaded[col] < 0).any():
                        raise ValueError(f"{col} cannot contain negative values.")
                uploaded["expiry_date"] = pd.to_datetime(uploaded["expiry_date"], errors="raise").dt.date
                st.session_state.inventory = uploaded
                st.success("Inventory CSV uploaded.")
                st.rerun()
        except Exception as exc:
            st.error(f"Could not process inventory CSV: {exc}")

    st.divider()
    st.subheader("Upload Sales History CSV")
    st.write("Required columns: date, item, demand")
    sales_file = st.file_uploader("Choose Sales History CSV", type=["csv"], key="sales_upload")
    if sales_file is not None:
        try:
            uploaded_sales = pd.read_csv(sales_file)
            if not {"date", "item", "demand"}.issubset(uploaded_sales.columns):
                st.error("Sales CSV must contain date, item and demand.")
            else:
                uploaded_sales["date"] = pd.to_datetime(uploaded_sales["date"], errors="raise")
                uploaded_sales["demand"] = pd.to_numeric(uploaded_sales["demand"], errors="raise")
                if (uploaded_sales["demand"] < 0).any():
                    raise ValueError("Demand cannot be negative.")
                st.session_state.sales = uploaded_sales
                st.success("Sales history uploaded.")
                st.rerun()
        except Exception as exc:
            st.error(f"Could not process sales CSV: {exc}")

    st.divider()
    st.subheader("Download Data")
    st.download_button("Download Inventory CSV",
        st.session_state.inventory.to_csv(index=False).encode("utf-8"),
        "inventory_data.csv", "text/csv")
    st.download_button("Download Sales History CSV",
        st.session_state.sales.to_csv(index=False).encode("utf-8"),
        "sales_history.csv", "text/csv")

st.divider()
st.caption("Smart Inventory Management System | Python | Streamlit | Pandas | Scikit-learn | Plotly")
