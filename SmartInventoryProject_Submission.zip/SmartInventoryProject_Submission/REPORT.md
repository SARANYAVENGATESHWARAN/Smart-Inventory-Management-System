# SMART INVENTORY MANAGEMENT SYSTEM
## Project Report

**Student Name:** [Enter your name]  
**Register Number:** [Enter your register number]  
**Department:** [Enter department]  
**Institution:** [Enter institution]  
**Project Guide:** [Enter guide name]  
**Academic Year:** [Enter academic year]

---

## Abstract
The Smart Inventory Management System is a web-based mini-project developed using Python and Streamlit. It provides a consolidated view of product stock, monitors expiry dates, analyses recorded defective quantities and estimates short-term product demand from historical sales records. Pandas is used for data handling, Plotly for interactive charts, NumPy for numerical calculations and Scikit-learn Linear Regression for a basic seven-day demand estimate. The application supports CSV upload and download so users can analyse inventory and sales records in a consistent format. The current implementation uses demonstration data by default and keeps edits and uploaded records in Streamlit session state; permanent database or cloud storage is not included.

## 1. Introduction
Inventory management involves maintaining information about products, available quantities, prices and expiry dates. When this information is handled manually, it can be difficult to identify stock that has expired, stock approaching its expiry date and products with recorded defects. Historical demand information can also help estimate the quantity likely to be required in the near future.

This project provides a simple browser-based interface that brings these activities together. It is intended as an educational prototype that demonstrates data processing, visualisation and a basic machine-learning workflow.

## 2. Problem Statement
Maintaining inventory records in separate files or manually can make it harder to monitor stock levels, identify expiry-related risks and review defective quantities. A simple integrated application is therefore required to display inventory information, classify products by expiry status, summarise defects and provide an indicative demand estimate from historical records.

## 3. Objectives
- Display product and stock summaries in a dashboard.
- Add and edit inventory records.
- Identify expired products and products expiring within 30 days.
- Summarise defective quantities and calculate a defect percentage.
- Estimate demand for the next seven days using historical demand data.
- Import and export inventory and sales records through CSV files.

## 4. Scope
The prototype is suitable for demonstrating small-scale inventory analysis using CSV data. It includes a local Streamlit interface and an in-memory session workflow. It does not currently include multi-user access, permanent database persistence, cloud deployment, automated notifications, barcode scanning or integration with a point-of-sale system.

## 5. Hardware and Software Requirements
**Hardware:** A computer capable of running Python and a modern web browser; internet access is required only when installing packages or accessing online services.

**Software:** Windows, macOS or Linux; Python 3.9 or later; Streamlit; Pandas; NumPy; Plotly; Scikit-learn; web browser.

## 6. System Architecture
The application follows a simple data-processing flow:

**CSV files / demonstration data → Streamlit interface → Pandas data processing →**
- **Dashboard and Plotly visualisations**
- **Expiry classification**
- **Defect calculations**
- **Linear Regression demand estimate**
- **CSV export**

The application runs locally. Data uploaded or edited by the user is held in Streamlit session state during the active session.

## 7. Modules

### 7.1 Dashboard
The dashboard displays the number of products, total stock quantity, expired product count, near-expiry product count and total defective units. Bar and pie charts provide a visual summary of stock quantity and expiry status.

### 7.2 Inventory Management
This module displays editable inventory records and allows a new product to be added. The record includes item name, category, quantity, unit price, expiry date and defect count. Basic validation checks prevent negative numeric values and require product name and category.

### 7.3 Expiry Monitoring
The system calculates the number of days between the current date and each product's expiry date. Products are displayed in three groups: expired (expiry date before today), near expiry (today through the next 30 days) and safe stock (more than 30 days remaining).

### 7.4 Defect Analysis
The module displays products with recorded defects, total defective units and a bar chart by product. Defect percentage is calculated as defective count divided by available quantity multiplied by 100. If quantity is zero, the displayed percentage is set to zero to avoid division by zero.

### 7.5 Demand Prediction
The user selects a product with historical demand records. The application assigns sequential day numbers and fits a Scikit-learn Linear Regression model to the demand values. The model estimates demand for the next seven days. Predictions are constrained to non-negative values. This is a basic educational estimate and should not be treated as a production forecasting model.

### 7.6 Data Upload and Download
The module accepts inventory CSV files with the required inventory columns and sales CSV files with date, item and demand columns. It checks required columns and converts numeric and date fields. Users can download the current inventory and sales records as CSV files.

## 8. Implementation Procedure
1. Install Python and the required Python packages.
2. Create the project folder and save the Streamlit source as `app.py`.
3. Initialise demonstration inventory and sales records.
4. Build the navigation menu and dashboard.
5. Implement inventory editing and product addition.
6. Add expiry classification and defect calculations.
7. Train a Linear Regression model for the selected product's demand history.
8. Implement CSV import and export.
9. Run the application using `py -m streamlit run app.py`.
10. Test each module and capture screenshots from the running application.

## 9. Testing
Complete this table using tests you personally perform. Do not mark a test as passed until you have observed the result.

| Test ID | Test case | Expected result | Actual result / status |
|---|---|---|---|
| T01 | Start the Streamlit application | Local application opens in browser | [Record result] |
| T02 | View dashboard | Summary metrics and charts are displayed | [Record result] |
| T03 | Add a product | New product appears in inventory | [Record result] |
| T04 | Edit a product quantity | Updated value is shown after saving | [Record result] |
| T05 | View expiry monitoring | Products appear in correct expiry groups | [Record result] |
| T06 | View defect analysis | Defect totals and chart are displayed | [Record result] |
| T07 | Select a product for prediction | Seven-day estimate is displayed | [Record result] |
| T08 | Upload a valid inventory CSV | Inventory data is loaded | [Record result] |
| T09 | Download inventory CSV | CSV file is downloaded | [Record result] |

## 10. Results and Screenshots
Insert genuine screenshots captured from the running application:
- Figure 1: Inventory dashboard.
- Figure 2: Inventory management.
- Figure 3: Expiry monitoring.
- Figure 4: Defect analysis.
- Figure 5: Demand prediction.
- Figure 6: CSV upload and download.

Describe only the results observed during your own tests. The supplied sample records are demonstration data and are not evidence of a real organisation's inventory.

## 11. Limitations and Future Enhancements
Current limitations include in-memory session storage, demonstration data, a simple linear demand model and the absence of user authentication or cloud deployment. Future versions could add a relational database, user roles, secure authentication, scheduled alerts, model evaluation with additional forecasting methods and optional cloud storage after those features are implemented and tested.

## 12. Conclusion
The Smart Inventory Management System demonstrates how Python-based data processing and visualisation can support basic inventory monitoring. It combines stock summaries, expiry grouping, defect analysis, simple demand estimation and CSV data exchange in one Streamlit application. The prototype provides a foundation for further development, particularly persistent storage, stronger validation and more advanced forecasting.

## References
1. Streamlit Documentation — https://docs.streamlit.io/
2. Pandas Documentation — https://pandas.pydata.org/docs/
3. NumPy Documentation — https://numpy.org/doc/
4. Plotly Python Documentation — https://plotly.com/python/
5. Scikit-learn Linear Models Documentation — https://scikit-learn.org/stable/modules/linear_model.html
